CREATE SCHEMA IF NOT EXISTS lvbag;

CREATE TABLE IF NOT EXISTS lvbag.pandactueelbestaand
(
    fid                       integer NOT NULL
        PRIMARY KEY,
    oorspronkelijkbouwjaar    integer,
    identificatie             varchar,
    status                    varchar,
    geconstateerd             boolean,
    documentdatum             date,
    documentnummer            varchar,
    voorkomenidentificatie    integer,
    begingeldigheid           date,
    eindgeldigheid            date,
    tijdstipregistratie       timestamp WITH TIME ZONE,
    eindregistratie           timestamp WITH TIME ZONE,
    tijdstipinactief          timestamp WITH TIME ZONE,
    tijdstipregistratielv     timestamp WITH TIME ZONE,
    tijdstipeindregistratielv timestamp WITH TIME ZONE,
    tijdstipinactieflv        timestamp WITH TIME ZONE,
    tijdstipnietbaglv         timestamp WITH TIME ZONE,
    geometrie                 geometry(Polygon, 28992)
);

CREATE INDEX IF NOT EXISTS pandactueelbestaand_geometrie_idx
    ON lvbag.pandactueelbestaand USING gist (geometrie);

CREATE INDEX IF NOT EXISTS pandactueelbestaand_identificatie_idx
    ON lvbag.pandactueelbestaand (identificatie);



