CREATE SCHEMA IF NOT EXISTS lvbag;

CREATE TABLE lvbag.nummeraanduidingactueelbestaand
(
    fid                       integer,
    huisnummer                integer,
    huisletter                varchar,
    huisnummertoevoeging      varchar,
    postcode                  varchar,
    typeadresseerbaarobject   varchar,
    openbareruimteref         varchar,
    identificatie             varchar,
    status                    varchar,
    geconstateerd             boolean,
    documentdatum             date,
    documentnummer            varchar,
    voorkomenidentificatie    integer,
    begingeldigheid           date,
    eindgeldigheid            date,
    tijdstipregistratie       timestamp WITH TIME ZONE,
    eindregistratie           timestamp WITH TIME ZONE,
    tijdstipinactief          timestamp WITH TIME ZONE,
    tijdstipregistratielv     timestamp WITH TIME ZONE,
    tijdstipeindregistratielv timestamp WITH TIME ZONE,
    tijdstipinactieflv        timestamp WITH TIME ZONE,
    tijdstipnietbaglv         timestamp WITH TIME ZONE,
    geometrie                 geometry
);
